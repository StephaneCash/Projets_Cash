var ca = "Salut bonjot z";
var e = ca.split(" ");
console.log(e);