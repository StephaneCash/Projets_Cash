			</div>
			<div class="pied_page">&emsp;
			<a href="." target="_self">
			<img src="images/stock.png" style="width:40px;border:none;" alt="" />
			</a>
			&emsp;
			<a href="facturation.php" target="_self">
			<img src="images/facturation.png" style="width:40px;border:none;" alt="" />
			</a>			
			</div>			
		</div>
	</div>
</body>
<?php 
	mysqli_close($liaison);
?>
</html>