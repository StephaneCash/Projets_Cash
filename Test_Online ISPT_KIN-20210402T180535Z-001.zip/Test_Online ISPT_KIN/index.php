
<?php 
	header("location:Pages/filiere.php");
?>