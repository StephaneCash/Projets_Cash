
<?php 
    session_start();

    require_once('connexiondb.php');

    $login = isset($_POST['login'])?$_POST['login']:"";
    $pwd = isset($_POST['pwd'])?$_POST['pwd']:"";

    $requeteU = "select * from utilisateur where login='$login' and pwd='$pwd' ";
    $resultatU = $pdo->query($requeteU);

    if($user=$resultatU->fetch()){
        if($user['etat']==1){
            $_SESSION['user']=$user;
            header('location:../index.php');
        }else{
            $_SESSION['Erreurlogin']=" <strong> Erreur !! </strong> Votre compte est désactivé. <br> Veuiller contacter l'Admin";
            header('location: login.php');
        }
    }else{
        $_SESSION['Erreurlogin']=" <strong> Erreur !! </strong> Nom d'utilisateur ou mot de passe incorrect.";
        header('location: login.php');
    }
    
?>