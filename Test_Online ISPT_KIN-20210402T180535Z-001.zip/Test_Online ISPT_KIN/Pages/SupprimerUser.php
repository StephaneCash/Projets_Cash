
<?php 
    require_once("identifier.php");
    require_once("connexiondb.php"); // Connexion à la BD
    
    // Verification des données 

    $idUser = isset($_GET['idUser'])?$_GET['idUser']:0;

    $requete = "delete from utilisateur where idUser=?";
    $param = array($idUser);
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);

    header('location: utilisateurs.php');
?>