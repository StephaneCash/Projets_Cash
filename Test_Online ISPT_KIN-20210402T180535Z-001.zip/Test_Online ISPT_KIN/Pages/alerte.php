
<?php
    require_once("identifier.php");
    $message = isset($_GET['message'])?$_GET['message']:"Erreur";
?>

<! DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title>Alerte</title>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    </head>

    <body>
        
        <!-- Insertion de la page menu -->
        <?php include("menu.php") ?> 
          
        <!-- Centrer le contenu de la page -->
        <div class="container">  
            
            <!-- Premier block composé d'entête et du corps (Côté recherche) -->
            <div class="panel panel-primary" style="margin-top: 80px;"> 
                <div class="panel-heading">Erreur : </div>
                <div class="panel-body">
                    <?php echo $message; ?>
                    <a href="<?php echo $_SERVER['HTTP_REFERER'] ?>"> Retour >>> </a>     

                </div>            
            </div>
        </div>
        
    </body>
</html>
