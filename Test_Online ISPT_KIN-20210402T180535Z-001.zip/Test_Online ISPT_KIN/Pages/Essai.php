<h3>Renseigner vos informations ici</h3> <p>



<form action="ad.php" method="post">
    Entrer votre nom : 
   <input type="text" placeholder="Entre votre nom" name ='nom'> <br>
   Entrer votre message : 
   <input type="text" placeholder="Entrer votre message" name = 'message'>
   <input type="submit" value="Valider">
</form>