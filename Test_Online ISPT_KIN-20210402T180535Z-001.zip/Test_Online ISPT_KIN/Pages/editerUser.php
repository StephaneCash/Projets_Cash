
<?php 
    require_once("identifier.php");
    require_once('connexiondb.php');

    $idUser = isset($_GET['idUser'])?$_GET['idUser']:0;

    $requeteUser = "select * from utilisateur where idUser=$idUser";
    $resultatUser = $pdo->query($requeteUser);
    $user = $resultatUser->fetch();

    $login = $user['login'];
    $email = $user['email'];
    $role = strtoupper($user['role']);
?>

<! DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title>Editer un utilisateur</title>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    </head>

    <body>
        
        <!-- Insertion de la page menu -->
        <?php include("menu.php") ?> 
          
        <!-- Centrer le contenu de la page -->
        <div class="container">  
            
            <!-- Premier block composé d'entête et du corps (Côté recherche) -->   
            <div class="panel panel-primary" style="margin-top: 80px;"> 
                <div class="panel-heading">Edition de l'utilisateur : </div>
                <div class="panel-body">
                    
                    <form method="post" action="updateUser.php" class="form" > 
                        
                    <!-- BLOC contenant id, nom et niveau de la filière-->
                        <div class="form-group"> 
                            <label for="idUser">id de l'user : <?php echo $idUser ?></label>
                            <input type="hidden" name="idUser" class="form-control" id="idUser" value = "<?php echo $idUser ?>"/> 
                        </div>
                        
                        <!-- Partie NOM -->
                        <div class="form-group"> 
                            <label for="login">Login : </label>
                            <input type="text" name="login" class="form-control" id="login" value = "<?php echo $login ?>"/> 
                        </div>

                        <!-- Partie POSTNOM -->
                        <div class="form-group"> 
                            <label for="email">Email : </label>
                            <input type="text" name="email" class="form-control" id="email" value = "<?php echo $email ?>"/> 
                        </div>
                        
                        <div class="form-group"> 
                            <label for="role">Rôle : </label>
                            <select name="role" class="form-control">
                                <option value="Admin" <?php if($role==="Admin") echo 'selected'; ?> >Administrateur</option>
                                <option value="Visiteur" <?php if($role==="Visiteur") echo 'selected'; ?> > Visiteur</option>
                            </select>
                        </div>

                         <!-- Bouton de recherche -->
                        <button type="submit" class="btn btn-success"> 
                            <span class="glyphicon glyphicon-save"> </span> Enregistrer
                        </button> &nbsp; &nbsp;&nbsp; &nbsp;
                        <a href="changePWD.php?idUser=<?php echo $idUser ?>">Changer le mot de passe</a>
                    </form>
                    
                </div>            
            </div>
        </div>
        
    </body>
</html>


