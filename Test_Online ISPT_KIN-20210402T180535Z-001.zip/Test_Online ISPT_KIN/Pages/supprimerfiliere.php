<?php 
    require_once("identifier.php");
    require_once("connexiondb.php"); // Connexion à la BD
    
    // Verification des données 

    $idf = isset($_GET['idF'])?$_GET['idF']:0;

    $requeteIns = "select count(*) countInscrit from inscrit where idfil = $idf";
    $resultatIns = $pdo->query($requeteIns);
    $tabCountIns = $resultatIns->fetch();
    $nbrInscr = $tabCountIns['CountInscrit'];
    
    if ($nbrInsr == 0){
        $requete = "delete from filiere where idfil=?";
        $param = array($idf);
        $resultat = $pdo->prepare($requete);
        $resultat->execute($param);
        header('location: filiere.php');
    }else{
        $msg = "Suppression impossible...";
        header('location: alerte.php?message = $msg');
    }
?>