
<?php 
      require_once("identifier.php");
      require_once("connexiondb.php"); // Connexion à la BD

      $requeteIns = "select * from inscrit";
      $resultatIns = $pdo->query($requeteIns);
      $inscrit = $resultatIns->fetch();
      
      $requeteFiliere = "select * from filiere";
      $resultatF = $pdo->query($requeteFiliere);

      $filiere = $resultatF->fetch();
      $idFiliere = $filiere['idfil'];

      $sexe = $inscrit['sexe'];
?>

<! DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title>Nouvel inscrit</title>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    </head>

    <body>
        
        <!-- Insertion de la page menu -->
        <?php include("menu.php") ?> 
          
        <!-- Centrer le contenu de la page -->
        <div class="container">  
            
            <!-- Premier block composé d'entête et du corps (Côté recherche) -->
            <div class="panel panel-primary" style="margin-top: 80px;"> 
                <div class="panel-heading"> Saisir les données du nouvel inscrit : </div>
                <div class="panel-body">
                    
                    <form method="post" action="insertNouveuInscrit.php" class="form" enctype="multipart/form-data">  
                        <div class="form-group"> 
                            <label for="nomInsIns">Nom : </label>
                            <input type="text" name="nomIns" placeholder="Taper le nom" class="form-control" id="nomF"  required />
                            
                            <label for="Postnom">Postnom : </label>
                            <input type="text" name="PostnomIns" placeholder="Taper le postnom" class="form-control" id="Postnom" required />                            
                        
                            <div class="form-group"> 
                            <label for="sexe">Sexe : </label>
                            <div class="form-check">
                                <label class="form-check-label"><input type="radio" class="form-check-input" name="sexe" value = "F"
                                <?php if($sexe === "F") echo "checked" ?>/> F </label>
                                <label class="form-check-label"><input type="radio" class="form-check-input" name="sexe" value = "M"
                                <?php if($sexe === "M") echo "checked" ?>/> M </label>
                            </div>
                        </div>

                        <label for="filiere"> Filière : </label>
                        <div class="form-group"> 
                             <select name="idfil" class="form-control" id="filiere">
                                   <?php while($filiere = $resultatF->fetch()) { ?>
                                        <option value=" <?php echo $filiere['idfil']; ?> "
                                            <?php if ($idFiliere === $filiere['idfil'] ) echo "selected" ; ?>>
                                            <?php echo $filiere['nomfil']; ?>
                                        </option>
                                   <?php } ?>                 
                             </select>      
                        </div>

                        </div>
                        
                        <!-- Partie liste déroulante de niveaux de filières -->
                        <label for="niveau"> Niveau : </label>
                        <div class="form-group"> 
                            <select name="niveau" class="form-control" id="niveau">
                                <option value="Licence">Licence</option>
                                <option value="Graduat">Graduat</option>
                                <option value="LMD" selected>LMD</option>
                            </select>
                        </div>
                        
                        <label for="niveau"> Section : </label>
                        <div class="form-group"> 
                            <select name="niveau" class="form-control" id="niveau">
                                <option value="Informatique">Informatique</option>
                                <option value="Electricité">Electricité</option>
                                <option value="Mécanique" selected>Mécanique</option>
                            </select>
                        </div>

                        <div class="form-group">Choisir une photo : <br><br>
                            <input type="file" name="photo" value="photo">
                        </div>

                         <!-- Bouton de recherche -->
                        <button type="submit" class="btn btn-success"> 
                            <span class="glyphicon glyphicon-save"> </span> Enregistrer
                         </button>
                    </form>
                </div>            
            </div>
        </div>
        
    </body>
</html>


