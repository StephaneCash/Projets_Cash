
<?php 
    require_once("identifier.php");
    require_once('connexiondb.php');

    $idi = isset($_GET['idI'])?$_GET['idI']:0;
    $requeteI = "select * from inscrit where idInscrit=$idi";
    $resultatI = $pdo->query($requeteI);
    $inscrit = $resultatI->fetch();

    $filiereL = "select section, niveau from filiere";
    $resulF =  $pdo->query($filiereL);
    $fil = $resulF->fetch();

    $nomI = $inscrit['nomInscrit'];
    $postnomI = $inscrit['postnomInscrit'];
    $section = $fil['section'];
    $niveau = $fil['niveau'];
    $sexe = $inscrit['sexe'];
    $photo = $inscrit['photo'];
    $idFiliere = $inscrit['idfil'];

    $requeteF = "select * from filiere";
    $resultatF = $pdo->query($requeteF);
    
?>

<! DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title>Editer inscrit</title>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    </head>

    <body>
        
        <!-- Insertion de la page menu -->
        <?php include("menu.php") ?> 
          
        <!-- Centrer le contenu de la page -->
        <div class="container">  
            
            <!-- Premier block composé d'entête et du corps (Côté recherche) -->   
            <div class="panel panel-primary" style="margin-top: 80px;"> 
                <div class="panel-heading">Edition du nouveau inscrit : </div>
                <div class="panel-body">
                    
                    <form method="post" action="updateInscrit.php" class="form" enctype="multipart/form-data"> 
                        
                    <!-- BLOC contenant id, nom et niveau de la filière-->
                        <div class="form-group"> 
                            <label for="idI">id du nouveau : <?php echo $idi ?></label>
                            <input type="hidden" name="idI" class="form-control" id="idI" value = "<?php echo $idi ?>"/> 
                        </div>
                        
                        <!-- Partie NOM -->
                        <div class="form-group"> 
                            <label for="nomF">Nom : </label>
                            <input type="text" name="nomInscrit" class="form-control" id="nomInscrit" value = "<?php echo $nomI ?>"/> 
                        </div>

                        <!-- Partie POSTNOM -->
                        <div class="form-group"> 
                            <label for="nomF">Postnom : </label>
                            <input type="text" name="postnomI" class="form-control" id="postnomI" value = "<?php echo $postnomI ?>"/> 
                        </div>

                        <!-- Partie SEXE -->
                        <div class="form-group"> 
                            <label for="sexe">Sexe : </label>
                            <div class="form-check">
                                <label class="form-check-label"><input type="radio" class="form-check-input" name="sexe" value = "F"
                                <?php if($sexe === "F") echo "checked" ?>/> F </label>
                                <label class="form-check-label"><input type="radio" class="form-check-input" name="sexe" value = "M"
                                <?php if($sexe === "M") echo "checked" ?>/> M </label>
                            </div>
                        </div>

                        <!-- Partie liste déroulante de niveaux de filières -->
                        <label for="filiere"> Filière : </label>
                        <div class="form-group"> 
                             <select name="filiere" class="form-control" id="filiere">
                                   <?php while($filiere = $resultatF->fetch()) { ?>
                                        <option value=" <?php echo $filiere['idfil']; ?> "
                                            <?php if ($idFiliere === $filiere['idfil'] ) echo "selected" ; ?>>
                                            <?php echo $filiere['nomfil']; ?>
                                        </option>
                                   <?php } ?>                 
                             </select>      
                        </div>
                        
                        <!-- Partie liste déroulante de niveaux de filières -->
                        <label for="niveau"> niveau : </label>
                        <div class="form-group"> 
                             <select name="niveau" class="form-control" id="niveau">
                                <option value="Licence" <?php if($niveau=="Licence") echo "selected" ?>>Licence</option>
                                <option value="Graduat" <?php if($niveau=="Graduat") echo "selected" ?>>Graduat</option>
                                <option value="LMD" <?php if($niveau=="LMD") echo "selected" ?>>LMD</option>
                            </select>      
                        </div>
                        
                        <!-- Partie liste déroulante de sections de filières -->
                        <label for="section"> Section : </label>
                        <div class="form-group"> 
                             <select name="section" class="form-control" id="section">
                             <option value="Informatique" <?php if($section=="Informatique") echo "selected" ?>>Informatique</option>
                                <option value="Electricité" <?php if($section=="Electricité") echo "selected" ?>>Electricité</option>
                                <option value="Mécanique" <?php if($section=="Mécanique") echo "selected" ?>>Mécanique</option>
                            </select>      
                        </div>
                        

                        <!-- Partie PHOTO -->
                        <div class="form-group"> 
                            <label for="photo">Photo : </label>
                            <input type="file" name="photo" /> 
                        </div>

                         <!-- Bouton de recherche -->
                        <button type="submit" class="btn btn-success"> 
                            <span class="glyphicon glyphicon-save"> </span> Enregistrer
                        </button>
                        
                    </form>
                    
                </div>            
            </div>
        </div>
        
    </body>
</html>


