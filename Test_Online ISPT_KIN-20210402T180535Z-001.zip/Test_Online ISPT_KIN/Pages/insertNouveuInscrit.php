
<?php 
    require_once("identifier.php");
    require_once("connexiondb.php"); // Connexion à la BD
    
    // Verification des données 

    $nomIns = isset($_POST['nomIns'])?$_POST['nomIns']:"";
    $postnomIns = isset($_POST['PostnomIns'])?$_POST['PostnomIns']:"";
    $sexe = isset($_POST['sexe'])?$_POST['sexe']:"";
    $niveau = isset($_POST['niveau'])?$_POST['niveau']:"";
    $filiere = isset($_POST['idfil'])?$_POST['idfil']:"";
    $section = isset($_POST['section'])?$_POST['section']:"";

    $photo = isset($_FILES['photo']['name'])?$_FILES['photo']['name']:"";
    $imageTem = $_FILES['photo']['tmp_name'];
    move_uploaded_file($imageTem,"../images/".$photo);

    $requete = "insert into inscrit(nomInscrit, postnomInscrit,sexe,idfil, photo) values(?,?,?,?,?)";
    $reqfil = "insert into filiere(section, niveau) values(?,?)";

    $param = array($nomIns, $postnomIns, $sexe, $filiere, $photo);
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);

    header('location: inscrit.php');
?>