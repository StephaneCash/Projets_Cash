
<?php
    require_once("identifier.php");
?>
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <a href="../index.php" class="navbar-brand" title="Gestion de toutes les filières de l'ISPT-KIN">
                <span class="glyphicon glyphicon-home small"> </span> 
                Gestion test
            </a>
        </div>
            <ul class="nav navbar-nav">
                <li><a href="#" title ="Aperçu global sur l'ISPT-Kin">ISPT</a></li>
                <li><a href="inscrit.php" title="Gestion de nouvels inscrits">Nouvels inscrits</a></li>
                <li><a href="utilisateurs.php" title="Users">Les utilisateurs</a></li>
                <li><a href="passationtest.php" title="Test en ligne ">Passer votre test</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="#" title ="User"><i class='glyphicon glyphicon-user '></i><?php echo " ". $_SESSION['user']['login']; ?></a></li>
                <li><a href="seDeconnecter.php" title="Déconnexion"><i class='glyphicon glyphicon-log-out '></i> Se déconnecter</a></li>
            </ul>
    </div>
</nav>
