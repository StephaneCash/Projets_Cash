<?php 
    require_once("identifier.php");
    require_once("connexiondb.php"); // Connexion à la BD
    
    // Verification des données 

    $idf = isset($_POST['idF'])?$_POST['idF']:0;
    $nomf = isset($_POST['nomF'])?$_POST['nomF']:"";
    $niveau = isset($_POST['niveau'])?$_POST['niveau']:"";
    $section = isset($_POST['section'])?$_POST['section']:"";

    $requete = "update filiere set nomfil=?, niveau=?, section=? where idfil=?";
    $param = array($nomf, $niveau, $section, $idf);
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);

    header('location: filiere.php');
?>