
<?php 
 session_start();
    require_once("identifier.php");
    require_once("connexiondb.php"); // Connexion à la BD
    
    // Verification des données 

    $idU = isset($_GET['idUser'])?$_GET['idUser']:0;
    $etat = isset($_GET['etat'])?$_GET['etat']:0;
    
    if($etat == 1)
        $newEtat = 0;
    else
        $newEtat = 1;

    $requete = "update utilisateur set etat=? where idUser=?";
    $param = array($newEtat, $idU);
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);

    header('location: utilisateurs.php');
?>