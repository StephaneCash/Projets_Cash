
<script>

    var tab = [1, 6, 8, 9, 0, 8, 16];
    
    var tab2 = [0];

    for(var i = 0; i < 7; i++){
        if(tab2 [0] < tab[i]){
            tab2[0] = tab[i];
        }
    }
    alert(tab2 [0]);

</script>
