
<?php require_once('identifier.php'); ?>

<! DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title>Nouvelle filière</title>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    </head>

    <body>
        
        <!-- Insertion de la page menu -->
        <?php include("menu.php") ?> 
          
        <!-- Centrer le contenu de la page -->
        <div class="container">  
            
            <!-- Premier block composé d'entête et du corps (Côté recherche) -->
            <div class="panel panel-primary" style="margin-top: 60px;"> 
                <div class="panel-heading"> Saisir les données pour la nouvelle filière : </div>
                <div class="panel-body">
                    
                    <form method="post" action="insertfiliere.php" class="form"> 
                        <div class="form-group"> 
                            <label for="nomF">Nom de la filière</label>
                            <input type="text" name="nomF" placeholder="Taper le nom de la filière" class="form-control" id="nomF" /> 
                        </div>
                        
                        <!-- Partie liste déroulante de niveaux de filières -->
                        <label for="niveau"> Niveau : </label>
                        <div class="form-group"> 
                            <select name="niveau" class="form-control" id="niveau">
                                <option value="all">Tous les niveaux</option>
                                <option value="Licence">Licence</option>
                                <option value="Graduat">Graduat</option>
                                <option value="LMD" selected>LMD</option>
                            </select>
                        </div>
                        
                        <label for="niveau"> Section : </label>
                        <div class="form-group"> 
                            <select name="section" class="form-control" id="niveau">
                                <option value="Informatique">Informatique</option>
                                <option value="Electricité">Electricité</option>
                                <option value="Mécanique" selected>Mécanique</option>
                            </select>
                        </div>
                         <!-- Bouton de recherche -->
                        <button type="submit" class="btn btn-success"> 
                            <span class="glyphicon glyphicon-save"> </span> Enregistrer
                         </button>
                    </form>
                </div>            
            </div>
        </div>
        
    </body>
</html>


