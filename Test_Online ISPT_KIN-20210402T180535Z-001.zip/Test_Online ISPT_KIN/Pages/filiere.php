
<?php 
    require_once("identifier.php");
    require_once("connexiondb.php"); // Connexion à la BD
    
    $nomf=isset($_GET['nomF'])?$_GET['nomF']:"";
    $niveau=isset($_GET['niveau'])?$_GET['niveau']:"all";

    $size=isset($_GET['size'])?$_GET['size']:5;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;
   
    // Vérification sur le choix de niveau de filière
    if($niveau=="all"){
        $requete="select * from filiere where nomfil like '%$nomf%' order by idfil limit $size offset $offset";
        $requeteCount="select count(*) countF from filiere where nomfil like '%$nomf%'";
    }else{
        $requete="select * from filiere where nomfil like '%$nomf%' and niveau= '$niveau' order by idfil limit $size";
        // die($requete);
        $requeteCount="select count(*) countF from filiere where nomfil like '%$nomf%' and niveau= '$niveau'"; 
    }
                  
    $resultatF=$pdo->query($requete); // Exécution de la requete

    $resultatCount=$pdo->query($requeteCount);
    $tabCount=$resultatCount->fetch();
    $nbrFiliere=$tabCount['countF'];
    $reste=$nbrFiliere % $size;
    
    if( $reste == 0)
        $nbrPage = $nbrFiliere/$size;
    else
        $nbrPage=floor($nbrFiliere/$size)+1;

?>

<! DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title>Gestion filières</title>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>

    <body>
        
        <!-- Insertion de la page menu -->
        <?php include("menu.php") ?> 
        
        <div class="container-fluid">
            <div class="row">
          
        <!-- Centrer le contenu de la page -->
        <div class="container">  
            
            <!-- Premier block composé d'entête et du corps (Côté recherche) -->
            
            <div class="panel panel-success" style="margin-top: 70px;"> 
                <div class="panel-heading"> Recherche des filières... </div>
                <div class="panel-body">
                                <!-- partie corps coté champ text (Taper le nom de la filière) -->
                     <form method="get" action="filiere.php" class="form-inline"> 
                        <div class="form-group"> 
                            <input type="search" name="nomF" placeholder="Taper le nom de la filière" class="form-control" 
                                   value="<?php echo $nomf; ?>"> 
                        </div>
                        <!-- Partie liste déroulante de niveaux de filières -->
                        <label for="niveau"> Niveau : </label>
                        <div class="form-group"> 
                            <select name="niveau" class="form-control" id="niveau">
                                <option value="all" <?php echo "selected" ; ?>>Tous les niveaux</option>
                                <option value="Licence" <?php if($niveau==="Licence") echo "selected" ?>>Licence</option>
                                <option value="Graduat" <?php if($niveau==="Graduat") echo "selected" ?>>Graduat</option>
                                <option value="Lmd" <?php if($niveau==="Lmd") echo "selected" ?>>LMD</option>
                            </select>
                        </div>
                         <!-- Bouton de recherche -->
                        <button type="submit" class="btn btn-success"> 
                            <span class="glyphicon glyphicon-search"> </span> Rechercher... 
                         </button> &nbsp; &nbsp;
                         
                         <!-- Partie pour ajout d'une nouvelle filière -->
                         <a href="nouvelleFiliere.php">
                             <span class="glyphicon glyphicon-plus"> </span>Nouvelle filière
                         </a>     
                    </form>
                </div>
            </div>
            
            <!-- Deuxième block composé d'entête et du corps (Côté affichage filière) -->
            <div class="panel panel-primary" style="font-family: 'Raleway', sans-serif; font-size: 16px;"> 
                <div class="panel-heading"> Liste des filières ( <?php echo $nbrFiliere; ?> Filières ) </div>
                <div class="panel-body">
                    
                    <!-- Début du tableau -->
                    <table class="table table-striped table-bordered">
                        <!-- Partie entête du tableau -->
                        <thead>
                            <tr>
                                <th>Id filière</th>
                                <th>Nom filière</th>
                                <th>Niveau</th>
                                <th>Section</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody> 
                            
                               <!-- Instruction pour afficher le résultat ds le tableau (Partie body) -->
                               <?php while($filiere=$resultatF->fetch()){?> 
                                   <tr>
                                        <td><?php echo $filiere['idfil'] ?></td>
                                        <td><?php echo $filiere['nomfil']?></td>
                                        <td><?php echo $filiere['niveau'] ?></td>
                                        <td><?php echo $filiere['section']?></td>
                                       <td>
                                           <!-- Affichges des glyphicons de rubrique 'Actions' -->
                                           <a href="editerfiliere.php?idF=<?php echo $filiere['idfil'] ?>">
                                               <span class="glyphicon glyphicon-edit "> </span>
                                           </a> &nbsp;
                                           
                                           <a onclick="return confirm('Etes-vous sûr de vouloir supprimer cette filière ?')" href="supprimerfiliere.php?idF=<?php echo $filiere['idfil'] ?>">
                                               <span class="glyphicon glyphicon-trash"> </span>
                                           </a>
                                       </td>
                                        
                                   </tr>
                               <?php }?>
                        </tbody>
                    </table>
                    <div>
                        <!-- Partie pagination -->
                        <ul class="pagination pagination-md">
                            <?php for($i=1; $i<=$nbrPage; $i++){ ?>
                               <li class="<?php if($i==$page) echo 'active' ?>" >
                                   <a href="filiere.php?page=<?php echo $i; ?>&nomF=<?php echo $nomf ?>&niveau=<?php echo $niveau ?>">
                                       <?php echo $i; ?>
                                   </a>
                               </li> 
                            <?php } ?>
                        </ul>
                    </div>
                  </div>
               </div>
            </div>
         </div>
       </div>
    </body>
</html>


