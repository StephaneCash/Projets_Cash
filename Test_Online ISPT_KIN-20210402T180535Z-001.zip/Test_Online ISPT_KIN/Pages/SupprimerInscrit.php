<?php 
    require_once("identifier.php");
    require_once("connexiondb.php"); // Connexion à la BD
    
    // Verification des données 

    $idInscrit = isset($_GET['idI'])?$_GET['idI']:0;

    $requete = "delete from inscrit where idInscrit=?";
    $param = array($idInscrit);
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);

    header('location: inscrit.php');
?>