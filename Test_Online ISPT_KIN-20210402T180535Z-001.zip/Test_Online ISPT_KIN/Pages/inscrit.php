
<?php 
    require_once("identifier.php");
    require_once("connexiondb.php"); // Connexion à la BD

    $nomPostnom=isset($_GET['nomPostnom'])?$_GET['nomPostnom']:"";
    $idfiliere=isset($_GET['idfiliere'])?$_GET['idfiliere']:0;

    $size=isset($_GET['size'])?$_GET['size']:3;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;

    

    $requeteFiliere = "select * from filiere";
   
    // Vérification sur le choix de niveau de filière
    if($idfiliere==0){
        $requeteInscrit="select idInscrit, nomInscrit, postnomInscrit,nomfil, sexe, section, niveau, photo 
                  from filiere as f, inscrit as i
                  where f.idfil = i.idfil
                  and (nomInscrit like '%$nomPostnom%' or postnomInscrit like '%$nomPostnom%')
                  order by idInscrit
                  limit $size 
                  offset $offset";
        
        $requeteCount="select count(*) countI from inscrit
                       where nomInscrit like '%$nomPostnom%' or postnomInscrit like '%$nomPostnom%'";
    }else{
        $requeteInscrit="select idInscrit, nomInscrit, postnomInscrit,nomfil, sexe, section, niveau, photo 
                  from filiere as f, inscrit as i
                  where f.idfil = i.idfil
                  and (nomInscrit like '%$nomPostnom%' or postnomInscrit like '%$nomPostnom%')
                  and f.idfil = $idfiliere
                  order by idInscrit
                  limit $size 
                  offset $offset";
        
        $requeteCount="select count(*) countI from inscrit
                  where(nomInscrit like '%$nomPostnom%' or postnomInscrit like '%$nomPostnom%') 
                  and idfil = $idfiliere";
    }
    // Exécution des requêtes FILIERE, COMPTAGE et INSCRIT
                  
    $resultatFiliere=$pdo->query($requeteFiliere);
    $resultatInscrit=$pdo->query($requeteInscrit); 
    $resultatCount=$pdo->query($requeteCount);

    $tabCount=$resultatCount->fetch();
    $nbrInscrit=$tabCount['countI'];
    $reste=$nbrInscrit % $size; 
    
    if( $reste == 0)
        $nbrPage = $nbrInscrit/$size;
    else
        $nbrPage=floor($nbrInscrit/$size)+1;

?>

<! DOCTYPE HTML>    nouveau
<html>
    <head>
        <meta charset="utf-8">
        <title>Gestion Inscrits</title>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    </head>

    <style>
        
    </style>

    <body>
        
        <!-- Insertion de la page menu -->
        <?php include("menu.php") ?> 
          
        <!-- Centrer le contenu de la page -->
        <div class="container">  
            
            <!-- Premier block composé d'entête et du corps (Côté recherche) -->
            <div class="panel panel-success" style="margin-top: 60px;"> 
                <div class="panel-heading"> Recherche des inscrits</div>
                <div class="panel-body">
                                <!-- partie corps coté champ text (Taper le nom de la filière) -->
                     <form method="get" action="inscrit.php" class="form-inline"> 
                        <div class="form-group"> 
                            <input type="text" name="nomPostnom" placeholder="Nom et postnom" class="form-control" 
                                   value="<?php echo $nomPostnom; ?>"> 
                        </div>
                        <!-- Partie liste déroulante de niveaux de filières -->
                        <label for="idfiliere"> Filière : </label>
                        <div class="form-group"> 
                            <select name="idfiliere" class="form-control" id="idfiliere">
                                <option value=0 > Toutes les filières </option>
                                <?php while($filiere = $resultatFiliere->fetch()){ ?>
                                     <option value="<?php echo $filiere['idfil'] ?>"
                                <?php if($filiere['idfil']==$idfiliere) { echo 'selected'; } ?> >
                                <?php echo $filiere['nomfil'] ?> </option>   
                                <?php } ?>    
                            </select>
                        </div>
                         <!-- Bouton de recherche -->
                        <button type="submit" class="btn btn-success"> 
                            <span class="glyphicon glyphicon-search"> </span> Rechercher... 
                         </button> &nbsp; &nbsp;
                         
                         <!-- Partie pour ajout d'un nouveau inscrit -->
                         <a href="NouveauInscrit.php">
                             <span class="glyphicon glyphicon-plus"> </span>Nouvel inscrit
                         </a>     
                    </form>
                </div>
            </div>
            
            <!-- Deuxième block composé d'entête et du corps (Côté affichage inscrit) -->
            <div class="panel panel-primary" style="font-family: 'Raleway', sans-serif; font-size: 16px;"> 
                <div class="panel-heading"> Liste des inscrits ( <?php echo $nbrInscrit; ?> Inscrits ) </div>
                <div class="panel-body">
                    
                    <!-- Début du tableau -->
                    <table class="table table-striped table-bordered">
                        <!-- Partie entête du tableau -->
                        <thead>
                            <tr>
                                <th>Id inscrit</th>
                                <th>Nom</th>
                                <th>Postnom</th>
                                <th>SEXE</th>
                                <th>Filière</th>
                                <th>Section</th>
                                <th>Niveau</th>
                                <th>Photo</th>
                                <th>Actions</th>
                            </tr>
                        </thead>     
                        <tbody> 
                            
                               <!-- Instruction pour afficher le résultat ds le tableau (Partie body) -->
                               <?php while($inscrit=$resultatInscrit->fetch()){?> 
                               <div class="tableau">
                                   <tr>
                                        <td><?php echo $inscrit['idInscrit'] ?></td>
                                        <td><?php echo $inscrit['nomInscrit']?></td>
                                        <td width = "13%"><?php echo $inscrit['postnomInscrit'] ?></td>
                                        <td><?php echo $inscrit['sexe']?></td>
                                        <td width = "23%"><?php echo $inscrit['nomfil']?></td>
                                        <td><?php echo $inscrit['section']?></td>
                                        <td><?php echo $inscrit['niveau']?></td>
                                       <td><img src="../Images/<?php echo $inscrit['photo']?>" width="25%" heigth="25%"></td>
                                       <td>
                                           <!-- Affichges des glyphicons de rubrique 'Actions' -->
                                           <a href="editerInscrit.php?idI=<?php echo $inscrit['idInscrit'] ?>">
                                               <span class="glyphicon glyphicon-edit "  title="Editer cette filière"> </span>
                                           </a> &nbsp;
                                           
                                           <a onclick="return confirm('Etes-vous sûr de vouloir supprimer cet inscrit ?')"    
                                              href="SupprimerInscrit.php?idI=<?php echo $inscrit['idInscrit'] ?>" title="Suppression de la filière">
                                               <span class="glyphicon glyphicon-trash"> </span>
                                           </a>
                                       </td>
                                        
                                   </tr>
                                   </div>
                               <?php }?>
                        </tbody>
                    </table>
                    <div>
                        <!-- Partie pagination -->
                        <ul class="pagination pagination-md">
                            <?php for($i=1; $i<=$nbrPage; $i++){ ?>
                               <li class="<?php if($i==$page) echo 'active' ?>" >
                                   <a href="inscrit.php?page=<?php echo $i ?>&nomPostnom=<?php echo $nomPostnom; ?>&idfiliere=<?php echo $idfiliere; ?>">
                                       <?php echo $i; ?>
                                   </a>
                               </li> 
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>


