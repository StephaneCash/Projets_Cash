
<?php

?>
<script>

</script>

<! DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <title>TEST ON LINE</title>
</head>

<style>
    h4{
        font-size : 15px;
        padding: 5%;
    }
    ol{
        font-size : 23px;
    }
    .lien{
        border: 0px solid black;
        width : 70%;
        margin-left : 73px;
    }
    a:hover /* Apparence au survol des liens */
    {
    text-decoration: underline;
    color: red;
    }
</style>

<body>

     <!-- Insertion de la page menu -->
     <?php include("menu.php") ?> 

    <div class="container">
        <div class="panel panel-primary" style="margin-top: 70px;">
            <div class="panel-heading" style="height": 30px;>
                Bienvenue dans la rubrique TEST 
            </div>
        </div>
 
        <div class="panel panel-success">
            <div class="panel-body">
                  <!-- Début du tableau -->
                   <table class="table table-striped table-bordered">
                        <!-- Partie entête du tableau -->
                        <thead>
                            <div class="panel-success">
                                <div class="panel-heading">
                                    <h3>Quelques consignes à suivre...</h3>
                                </div>
                            </div>
                            
                            <tr>
                                <th>Facteur temps</th>
                            </tr>
                        </thead>
                      
                        <tbody>      
                  <!-- Instruction pour afficher le résultat ds le tableau (Partie body) -->
                           <tr>
                                <td>
                                    Le facteur temps est un grand atout dans tout langage de programmation hbchbschjsgbcyusdgc
                                </td> 
                           </tr>
                        </tbody>
                  </table> 
                      
                  <table class="table table-striped table-bordered">
                 <!-- Partie entête du tableau -->
                        <thead>
                            <tr>
                                <th>Comment répondre aux questions ?</th>
                            </tr>
                        </thead>
                      
                        <tbody>  
                  <!-- Instruction pour afficher le résultat ds le tableau (Partie body) -->
                           <tr>
                                <td>
                                    Le facteur temps est un grand atout dans tout langage de programmation hbchbschjsgbcyusdgc
                                </td> 
                           </tr>
                        </tbody> 
                  </table> 
            </div>
        </div> 
    </div>
    
    <div class="lien">
       Cliquer <a href="../Quiz/Quiz.php" title="Test évaluatif pour être admis étant un étudiant">ici </a>pour commencer votre test
    </div>
    
</body>
</html>
