<?php 
    require_once("identifier.php");
    require_once("connexiondb.php"); // Connexion à la BD
    
    // Verification des données 

    $nomf = isset($_POST['nomF'])?$_POST['nomF']:"";
    $niveau = isset($_POST['niveau'])?$_POST['niveau']:"";
    $section = isset($_POST['section'])?$_POST['section']:"";

    $requete = "insert into filiere(nomfil, niveau, section) values(?,?,?)";
    $param = array($nomf, $niveau, $section);
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);

    header('location: filiere.php');
?>