<?php
    require_once("identifier.php");
    require_once("connexiondb.php"); // Connexion à la BD
    
    // Verification des données 

    $idi = isset($_POST['idI'])?$_POST['idI']:0;
    $nomIns = isset($_POST['nomInscrit'])?$_POST['nomInscrit']:"";
    $postnomIns = isset($_POST['postnomI'])?$_POST['postnomI']:"";
    $niveau = isset($_POST['niveau'])?$_POST['niveau']:"";
    $section = isset($_POST['section'])?$_POST['section']:"";
    $sexe = isset($_POST['sexe'])?$_POST['sexe']:"";
    $filiere = isset($_POST['filiere'])?$_POST['filiere']:1;

    $nomphoto = isset($_FILES['photo']['name'])?$_FILES['photo']['name']:"";
    $Img_temp = $_FILES['photo']['tmp_name'];
    move_uploaded_file($Img_temp, "../Images/" .$nomphoto);

    
   // VERIFICATION SI LE CHAMP DE PHOTO CONTIENT UN NOM POUR MODIFIER
    if(!empty($nomphoto)){
        $niv = "update filiere set niveau=?, section=? where idfil=?";
        $co = array($niveau, $section, $filiere);
        $rep = $pdo->prepare($niv);
        $rep->execute($co);
    
    
        $requete = "update inscrit set nomInscrit=?, postnomInscrit=?, sexe=?, photo=?, idfil=? where idInscrit=?";
        $param = array($nomIns, $postnomIns, $sexe, $nomphoto, $filiere, $idi);
        $resultat = $pdo->prepare($requete);
        $resultat->execute($param);
    } else{
        $niv = "update filiere set niveau=?, section=? where idfil=?";
        $co = array($niveau, $section, $filiere);
        $rep = $pdo->prepare($niv);
        $rep->execute($co);

        $requete = "update inscrit set nomInscrit=?, postnomInscrit=?, sexe=?, idfil=? where idInscrit=?";
        $param = array($nomIns, $postnomIns, $sexe,$filiere, $idi);
        $resultat = $pdo->prepare($requete);
        $resultat->execute($param);
    }

    header('location: inscrit.php'); 
?>