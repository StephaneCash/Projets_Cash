create database gestion_test;
use gestion_test;
create table filiere(idfil int(4) auto_increment primary key, nomfil varchar(100), niveau varchar(80), section varchar(50));
insert into filiere values('1', 'Informatique industrielle et Réseaux', 'Graduat', 'Informatique');
insert into filiere values('2', 'Informatique de gestion', 'Graduat', 'Informatique');
insert into filiere values('3', 'Electrotechnique', 'Graduat', 'Electricite');
insert into filiere values('4', 'Electronique', 'Graduat', 'Electrcite');
insert into filiere values('5', 'Electromecanique', 'Graduat', 'Mecanique');
insert into filiere values('6', 'Construction metallique et navale', 'Graduat', 'Mecanique');
insert into filiere values('7', 'Mecanique agricole et automobile', 'Graduat', 'Mecanique');
insert into filiere values('8', 'Informatique industrielle', 'Licence', 'Informatique');
insert into filiere values('9', 'Telecommunication', 'Licence', 'Electricite');
insert into filiere values('10', 'Electroenergetique', 'Licence', 'Electricite');
insert into filiere values('11', 'Mecanique Appli', 'Licence', 'Mecanique');
insert into filiere values('12', 'Mecanique Pro ', 'Licence', 'Mecanique');

create table inscrit(idInscrit int(4) auto_increment primary key, nomInscrit varchar(100), postnomInscrit varchar(255), sexe varchar(5), photo varchar(100), idfil int(4));
insert into inscrit values('7', 'SADO', 'Grace', 'M', 'alain.JPG', '8');
insert into inscrit values('8', 'BANGO', 'Guelord', 'M', 'guelord.JPG', '8');
insert into inscrit values('9', 'KAKESA', 'Mira', 'F', 'aladin.JPG', '1');
insert into inscrit values('10', 'KASONGO', 'Divine', 'F', 'divine.JPG', '3');

create table utilisateur(id int(4) primary key auto_increment, login varchar(255), email varchar(255), role varchar(255),
                          etat int(1), Pwd varchar(255));
insert into utilisateur values('1', 'admin', 'kikonistephane@gmail.com', 'Admin', 1, md5('1234') );

Alter table inscrit add constraint foreign key(idfil) references filiere(idfil);