
<! DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<title>Quiz en ligne</title>
	<meta name="description" content="Questionnaire à choix multiples en PHP" />
	<link href='styles/style.css' rel='stylesheet' type='text/css' />
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script language="Javascript" src="js/questions_online.js"></script>
</head>
<body>

	<div class="div_conteneur_parent">
	<div id="infos" class="texte_div"></div>
		<div class="div_conteneur_page">
			
			 <!-- Insertion de la page menu -->
			 <?php include("../pages/menu.php") ?> 
			
			<div class="div_int_page">
			
			<div style="width:100%;display:block;text-align:center;">
			</div>
			
			<div class="div_saut_ligne" style="height:30px;">
			</div>						
			
			<div style="float:left;width:10%;height:40px;"></div>
			<div style="float:left;width:80%;height:40px;text-align:center;">
			<div class="calque_titre">
				Questionnaire à choix multiples sur PHP - Cliquez sur la bonne réponse
			</div>
			</div>
					
			<div style="float:left;width:10%;height:40px;"></div>
				
			<div class="div_saut_ligne">
			</div>		
			
			<div style="width:100%;height:auto;text-align:center;">
						
			<div style="width:800px;display:inline-block;" id="conteneur">
			
				<div class="centre">
					<div class="titre_centre" id="question">
						
					</div>	
				</div>
			
				<div class="colonne" id="liste" style="font-family : calibri;">
					<div class="calque_rep" id="rep1" onClick = "valider(1)"></div>
					<div class="calque_rep" id="rep2" onClick = "valider(2)"></div>
					<div class="calque_rep" id="rep3" onClick = "valider(3)"></div>
					<div class="calque_rep" id="rep4" onClick = "valider(4)"></div>
				</div>
				
				<div class="centre">
					<div class="titre_centre" id="apercu" style="text-align:left;font-family:Calibri; height : 70px;">
					<input type="button" value="commencer" style="margin-left:10px; " onClick="debuter();" />
					<div id="stats" style="float:right;padding-right:15px;">
					<div style="float:left;">Votre score :&nbsp;</div>
					<div id="score" style="float:left;font-weight:bold;">10</div>
					<div style="float:left;">, Questions restantes :&nbsp;</div>
					<div id="restant" style="float:left;font-weight:bold;">10</div>
					</div>
				</div>	
			</div>					
				
			</div>
			
			</div>

			<div class="div_saut_ligne" style="height:50px;">
			</div>	
			
			</div>
		</div>
	
	</div>
	
</body>
<script type="text/javascript" language="javascript">

	var bonne_rep = 0; var nb_questions = 10;
	var nb_erreurs = 0; var mem_nb_alea="";
	var jouer=false;
	
	function debuter()
	{
		jouer = true;
		bonne_rep = 0; nb_questions = 10;
		nb_erreurs = 0; mem_nb_alea="";
		init();
		suivant();
	}
	
	function init()
	{
		document.getElementById('restant').innerText = nb_questions;
		document.getElementById('score').innerText = 10-nb_erreurs;	
	}

	function valider(num_rep){
		if(jouer == false)
			return;
		
		if(num_rep != bonne_rep)
		nb_erreurs++;

		nb_questions--; 
		if(nb_questions == 0)
			jouer = false;

		init();
		suivant(); 
	}

	function suivant(){
		var indice;
		var test = true; var nb_alea = 0;

		if(jouer == false)
			return;
		
		while(test ==  true){

		    nb_alea = Math.floor(Math.random() * 65) + 1;
			if(mem_nb_alea.indexOf("-" + nb_alea + "-")>-1)
				nb_alea = Math.floor(Math.random()*65) + 1;
			else{
				test = false;
				mem_nb_alea += "-" + nb_alea + "-";
			}
		}

		var chaine_question = questions(nb_alea);
		// alert(chaine_question); 

		var tab_question = chaine_question.split('*');

		document.getElementById('question') .innerText = tab_question[0];

		for(indice = 1; indice<=4; indice++){
			document.getElementById('rep' + indice) .innerText = tab_question[indice];
		}

		bonne_rep = tab_question[5];

		if(bonne_rep > 5 ){
			alert('Vous avez reussi, vous allez être rappelé après quelques jours. ');
		}
	}
	
</script>

<form action="reussite.php">
		Une fois fini, soumettez vos réponses ici <input type="submit" value="Soumettre">
	</form>

</html>
	