
function questions(numero)
{
	var chaine="";
	switch(numero)
	{
		case 1:
		chaine="A quoi sert l'instruction 'echo' en PHP?*Afficher un message*Lire une variable*Compter la longueur de cara*Cacher le message*1";
		break;
		case 2:
		chaine="Quelle est la capitale de la RDC ?*Kindu*Bunia*Kinshasa*Minembwe*3";
		break;
		case 3:
		chaine="il existe combien des sortes de tension en electricité et sitez le? *tension un et tension deux*tension alternatif et continue*adverb*tension simple et tension composé*3";
		break;
		case 4:
		chaine="Il existe combien de sorte des courant en electricité?*4*2*5*3*2";
		break;
		case 5:
		chaine="Quelle est la langue la plus parlée au monde?*chinois*francais*englais*3";
		break;
		case 6:
		chaine="Que signifie CFA?*bring*caisse de franc colonial*Franc de colonie francaise*2";
		break;
		case 7:
		chaine="shoot the correct answer; the passive is in 1,2,3*I am sent to the market*I have sent peter to the market*I had sent peter to the market*1";
		break;
		case 8:
		chaine="Que le rôle du premier ministre dans un Etat?*Le preministre est le representant de president*Il assure le role de president à son absence*Il eet d'abord le chef du gouvernement. il dirige l'action du gouvernement*le prémier ministre assume les responsabilité du province*1";
		break;
		case 9:
		chaine="Que signifie UNESCO?*Organisation de nation unie pour l'education la science et la culture*union nationnal des education scolaire au congo*Uniter nationnal economique pour des société congolaise*1";
		break;
		case 10:
		chaine="En mathematique la formule de deltat est?*X-Y*B carré-4AC*AX-B carré*2";
		break;
		case 11:
		chaine="Dans une carte mère  le micro processeur est il le serveau de resonnement vrai ou faux ?*vra* faux*1";
		break;
		case 12:
		chaine="Il existe combien des sortes de peripherique en informatique?*5*6*3*3";
		break;
		case 13:
		chaine="Donnez la meilleur formule de l'inductance?*L=Q/WI*L=Q/I*L=XL/W*Z=LW*3";
		break;
		case 14:
		chaine="Qu'est ce qu'un circuit électrique?*c'est l'ensemble d'une installation electrique*ce la reparation des appareil electrique*c'est le chemin à travers lesquels s'établit le courant électrique, composé de: génerateur, récepteur, fils conducteur, interrupteur et protection*3";
		break;
		case 15:
		chaine="Qu'est que ce la MITOSE?*division des sellulies somatiques*division caire*est la division de zygote*est le mode de division cellulaire qui consiste à la division d'une cellule mere diploides 2n en deux cellules filles dipoide.*4";
		break;
		case 16:
		chaine="Comment peut-on déplacer le courant electrique?*Augmenter la tension pour diminuer la section du fil conducteur donc la resistance ainsi que les pertes en lignes à chaque à chaque fois n'oublié pas de mettre sous la terre le fil de garde pour protéger la linge des ondes de srtension calculer arc*Faut le convertir en continu et le rehausser pour eviter les pertes *augmentasion de tension*on transformer le C.A en C.C pour éviter le perte du courant*3";
		break;
		case 17:
		chaine="HTTP signifie quoi?*height transport de traitement protocol*hypertext transfer protocol*langage de l'internet*2";
		break;
		case 18:
		chaine="COBOL c'est quoi?*c'est un extention*est protocol*SGBD*Est un langage de programmation*3";
		break;
		case 19:
		chaine="Un ordinateur peut démarré sans BIOS?*Vrai*Faux*2";
		break;
		case 20:
		chaine="Sur quoi brache t-on les lecteurs ou les gravers de CD ou de DVD?*Sur le port IDE*AGP*PCI*SATA*1";
		break;
		case 21:
		chaine="Que designe t-on par bande passante?*La quantité des dennées maximale transmissible par unité du temps*La quantité des données maximale transmise par unité de temps*La vitesse de transfert des données*3";
		break;
		case 22:
		chaine="La pile présente sur la carte mere sert à: le secteur*Retenir l'heure uniquement*Retenir l'hheur et alimenter le bios*Alimenter les petite ampoules sur la facade de l'ordinateur*2";
		break;
		case 23:
		chaine="Le nombre qui suit le nombre 4 en base 5 est?*10*5*0*A*1"       
         
		break;
		case 24:
		chaine="combien de bytes y a t-il dans un giga-octet?*1000000*1048576000*1073741824*1024024024*3";
		break;
		case 25:
		chaine="Que signifie css?*Cascading styl sheet*commont style settings*compiled style sheet*1";
		
		case 26:
		chaine="A quoi sert le css?*il permet de mieux organiser notre HTML*il gére les animations et les données utilisateur*il permet de mettre en forme et styliser notre contenu HTML*3";
		break;
		case 27:
		chaine="A quoi peut on comparer le css?*au squelette de la page*a l'habillage de la page*aux muscles de la page*2";
		break;
		case 28:
		chaine="Lequel n'est pas un fabricant de l'ordinateur?*IBM*Microsoft*Apple*Sun*4";
		break;
		case 29:
		chaine="Lorsque l'autotest est terminé, un bip court indique que?:*Le systeme d'exploitation est chargé*Il y a un probleme dans la memoire*L'autotest  a été realiser avec succés*un peripherique systéme est inconnu*3";
		break;
		case 30:
		chaine="Comment c'est nomme l'unité minimale allouée par un disque dur lors d'une opération d'écriture?*Le secteur*La FAT*Le bloks*2";
		break;
		case 31:
		chaine="Laquelle des ces imprimantes possede une memoire ROM?*Matriciel*Jet d'encre*Laser*Toutes*4";
		break;
		case 32:
		chaine="Le bus PCI est un bus:*Local*Classique*Externe*1";
		break;
		case 33:
		chaine="Avec quelle outil devez-vous nettoyer un clavier sali?*Une bombe a air comprimé*Un chiffon et un detrgent ménager*Un chiffon et un nettoyant adapté*Aucune de ces reponse*3";
		break;
		case 34:
		chaine="Quel est l'atout de la technologie RAID?*Formater le disque*Le partioner*Le partager*L'overcloker*2";
		break;
		case 35:
		chaine="Une memoire n'est pas de type?*ROM*RUM*RAM*EEPROM*2";
		break;
		case 36:
		chaine="Qu'est ce que lr MP3?*Une methode de protection de fichiers audio*Un protocol d'échange de fichiers audio*un format de compression de données audio*3";
		break;
		case 37:
		chaine="QUI AS DECOUVERT L'EMBOUCHIR DU FLEUVE CONGO?*DIEGO CAO*STANLEY*ROI KO*ROI LEONPAUL2*1";
		break;
		case 38:
		chaine="QUELLE EST L'ANNEE DE NAISSANCE DU PROPHETE MOHEMET?*L'AN 600*L'AN 700*1644*1995*1";
		break;
		case 39:
		chaine="QUI FIT LE FONDATEUR DE LA RELIGION CHRETIEN? .*ROI CONSTANTIN*ROI SPARTAAQUIS*ROI NZINGA KUVU**1";
		break;
		case 40:
		chaine="QUI AS ECRIT LE TORA?.*MOISE*JOSUE*DAVID*PAUL*1";
		break;
		case 41:
		chaine="DONNEE NOUS LA FORMULE DE L'EAU*HDO*COD*1";
		break;
		case 42:
		chaine="QUI FIT LE PREMIER MINISTRE EN REPUBLIQUE DEMOCRATIQUE DU CONGO?*PATRICE EMERI LUMUMBA*SAMI BADIBANGA*BRUNO TSHIBALA*1";
		break;
		case 43:
		chaine="QUI EST LE PREMIER PRESIDENT A PASSEE A LA TRANSITION EN REPUBLIQUE DEMOCRATIQUE DU CONGO?.*JOSEPH KABILA*JOSEPH MOBUTU*MZEE LAURA DESIRE KABILA*1";
		break;
		case 44:
		chaine="QUI FIT LE PREMIER PRESIDENT DE LA REPUBLIQUE DEMOCRATIQUE DU CONGO?*JOSUE KASAVUBU*LUMUMBA*JOSEPH KABILA*NICOLA SARKOZY*1";
		break;
		case 45:
		chaine="qui fit le premiere president noir americain?*BARACK OBAMA*JOSEPH KABILA*JOSEPH KASAVUBU*PAUL KANGAME*1";
		break;
		case 46:
		chaine="donnee la date de naissance de jesus christ?*25 decembre l'an 0*20 avril 1995*1";
		break;
		case 47:
		chaine="qui es lhomme qui as beaucoup duree en prison :SIMON KIMBANGU?*NELSON LANDELA*FIDEL CASTRO*RAUL CASTRO*1";
		break;
		case 48:
		chaine="NELSON MANDELA A DUREE COMBIEN DANNEE EN PRISON?*20ans*27ans*30ans*26ans*2";
		break;
		case 49:
		chaine="Qui est le fondateur de l'ampire du maly?*CIDIQI DIABATE*KEITA BALI*SOUDIANTA KEITA*KEITA RABA*3";
		break;
		case 50:
		chaine="Quel est le président qui a mis fin au genocide au rwanda?*Paul MUGABE*Paul KAGAME*Paul BIYA*AZARIAS ROUBERWA*2";
		break;
		case 51:
		chaine="Donnez le nom de la ville qui est entourer par trois montagne?*BRICEL*ROME*PARIS*KIGALI*2";
		break;
		case 52:
		chaine="Quel est le 5éme president de la 8éme etat francaise? *FRANCOIS OLANDE*BILCLINTON*NICOLAS SARKOSU*AMANUEL MACRON*4";
		break;
		case 53:
		chaine="Donnez la signification de URL ?*Uniform ressource Locator *Unité Ressource Localisateur*Union Ressource luk up*unicial restoratio logique*1";
		break;
		case 54:
		chaine="Quelle est l'ancienne appellation de la RDC?*Zaire*congo belge*congo*republique democratique du congo*2";
		break;
		case 55:
		chaine="MYSQL c'est quoi?*c'est langage de programmation*est un langage dynamique*est un langage statique*c'est un SGBDR*4";
		break;
		case 56:
		chaine="Comment s'appelle l'homme qui aida Jésus-Christ à transporter la croix?*SIMON DE SIREINE*SIMON PIERRE*JEAN BAPTISTE*SIDIQI DIABATE*1";
		break;
		case 57:
		chaine="Quel est l'unité de l'intensité du courant éléctrique?*ampermaitre*volt*amper*4";
		break;
		case 58:
		chaine="Comment appel t-on le vice premiere ministre qui a fait trois mois au pouvoir?*MATATA MPONYO MAPONG*SAMY BADIBANGA*BRINO TSHIBALA*LUMUMBA*2";
		break;
		case 59:
		chaine="Qu'elle est le vrai nom de lady ber?*CHOE LE BOURGEOIS*DORCAS*BLANCHE NEIGE*MARINETTE*4";
		break;
		case 60:
		chaine="Quelle est l'auteur de cette oeuvre:un crocodile à luwozi?*KADIMA NZUZI MUKALA*AIME saiser*ZAMENGA BATUKEZANGA*NUMBI CLAUDE*3";
		break;
		case 61:
		chaine="Comment appelle-t-on le dieu de l'amour?*reigne ostara*blanche neige*All*cupidon*3";
		break;
		case 62:
		chaine="Où se situe le siège de l'ONU?*Malawi*Aux Etats-unis*france*tirqui*2";
		break;
		case 63:
		chaine="Qu'est ce qu'un fisible?*Est un appareil électrique*Est un appareil de protection*est un dijoncteur*c'est un partie des outils electrique*2";
		break;
		case 64:
		chaine="Que signifie PC dans le domaine informatique?*PERSONAL COMPUTER*PROTOCOL DE CARTE* POL COMPUTER*1";
		break;
		case 65:
		chaine="Qu'est ce qu'un condasateur*est un isolant electrique?*est l'ensemble de deux fils conducteur separé par un isolant*c'est l'appareil electrique*est une partie positif d'un fils electrique*2";
		break;
	}
	
	return chaine;
}