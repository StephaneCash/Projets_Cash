
function questions(numero)
{
	var chaine="";
	switch(numero)
	{
		case 1:
		chaine="A quoi sert l'instruction 'echo' en PHP?*Afficher un message*Lire une variable*Compter la longueur de cara*Cacher le message*1";
		break;
		case 2:
		chaine="Quel opérateur est utilsé pour concaténer des chaines de caractères ?*+*CONCAT()*.*&*1";
		break;
		case 3:
		chaine="En quelle année a été inventé le PHP ?*1998*1977*1984*1994*4";
		break;
		case 4:
		chaine="La fonction implode() *N'existe pas en PHP*Convertit un mot en tableau de lettres*Convertit un tableau de lignes en fichier*Convertit un tableau en liste selon un séparateur*4";
		break;
		case 5:
		chaine="Que faut-il utiliser pour modifier l'en-tête d'une réponse HTTP ?*Header()*Des balises <head> </head>*Ce n'est pas possible*Write_header*1";
		break;
		case 6:
		chaine="Que fait array_pop() ? *Retourne le premier élément d'un tableau et le supprime*Retourne le premier élément d'un tableau sans le supprimer*Retourne le dernier élément d'un tableau et le supprime*Retourne le dernier élément d'un tableau sans le supprimer*3";
		break;
		case 7:
		chaine="Comment rendre invisible un champ dans un formulaire ?*<input type='disable'*<input type='readonly'*<input type=''*<input type='hidden'*1";
		break;
		case 8:
		chaine="Que signifie PHP ?*Programme Hyper Produit*Procedural Programmation Hyper*Hypertext Preprocessor*Programmation Pin Hyper*3";
		break;
		case 9:
		chaine="Que signifie UNESCO?*Organisation de nation unie pour l'education la science et la culture*union nationnal des education scolaire au congo*Uniter nationnal economique pour des société congolaise*1";
		break;
		case 10:
		chaine="En mathematique la formule de deltat est?*X-Y*B carré-4AC*AX-B carré*2";
		break;
		case 11:
		chaine="Dans une carte mère  le micro processeur est il le serveau de resonnement vrai ou faux ?*vra* faux*1";
		break;
		case 12:
		chaine="Il existe combien des sortes de peripherique en informatique?*5*6*3*3";
		break;
		case 13:
		chaine="Donnez la meilleur formule de l'inductance?*L=Q/WI*L=Q/I*L=XL/W*Z=LW*3";
		break;
		case 14:
		chaine="Qu'est ce qu'un circuit électrique?*c'est l'ensemble d'une installation electrique*ce la reparation des appareil electrique*c'est le chemin à travers lesquels s'établit le courant électrique, composé de: génerateur, récepteur, fils conducteur, interrupteur et protection*3";
		break;
		case 15:
		chaine="Comment déclarer une variable en PHP ?*Var a ;*Dim a As Integer ;*int a ;*$a ; *4";
		break;
	
	}
	
	return chaine;
}